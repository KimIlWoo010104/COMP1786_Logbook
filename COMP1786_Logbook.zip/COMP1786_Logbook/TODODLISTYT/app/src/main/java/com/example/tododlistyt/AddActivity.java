package com.example.tododlistyt;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddActivity extends AppCompatActivity {
    EditText task_input, description_input, completion_input;
    Button Add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        task_input = findViewById(R.id.task_input);
        description_input = findViewById(R.id.description_input);
        completion_input = findViewById(R.id.completion_input);
        Add_button = findViewById(R.id.Add);
        Add_button.setOnClickListener(view -> {
            MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);
            myDB.addTask(task_input.getText().toString().trim(),
                    description_input.getText().toString().trim(),
                    completion_input.getText().toString().trim());
        });
    }
}