package com.example.tododlistyt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UpdateActivity extends AppCompatActivity {

    EditText task_input, description_input, completion_input;
    Button Update_button, Delete_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        task_input = findViewById(R.id.task_input2);
        description_input = findViewById(R.id.description_input2);
        completion_input = findViewById(R.id.completion_input2);
        Update_button = findViewById(R.id.Update);
        Delete_button = findViewById(R.id.Delete);

        // Get initial values from Intent and set them in the EditTexts
        Intent intent = getIntent();
        if (intent.hasExtra("id") && intent.hasExtra("name") &&
                intent.hasExtra("description") && intent.hasExtra("completion")) {

            // Set text fields with received data
            task_input.setText(intent.getStringExtra("name"));
            description_input.setText(intent.getStringExtra("description"));
            completion_input.setText(intent.getStringExtra("completion"));
        } else {
            Toast.makeText(this, "No Data", Toast.LENGTH_LONG).show();
        }

        // Update logic
        Update_button.setOnClickListener(view -> {
            String id = intent.getStringExtra("id");
            String updatedName = task_input.getText().toString().trim();
            String updatedDescription = description_input.getText().toString().trim();
            String updatedCompletion = completion_input.getText().toString().trim();

            MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
            myDB.updateData(id, updatedName, updatedDescription, updatedCompletion);
        });

        Delete_button.setOnClickListener(view -> {
            String id = intent.getStringExtra("id");
            MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
            myDB.deleteOneRow(id);
            finish();
        });
    }
}